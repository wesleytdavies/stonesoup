using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WesValidatedRoom : Room
{
    private bool _hasUpExit;
    private bool _hasDownExit;
    private bool _hasLeftExit;
    private bool _hasRightExit;

    private bool _hasUpDownPath;
    private bool _hasUpLeftPath;
    private bool _hasUpRightPath;
    private bool _hasDownLeftPath;
    private bool _hasDownRightPath;
    private bool _hasLeftRightPath;

    private void ValidateRoom()
    {
        int[,] indexGrid = loadIndexGrid();
        Vector2Int upExit = new Vector2Int(LevelGenerator.ROOM_WIDTH / 2, LevelGenerator.ROOM_HEIGHT - 1);
        Vector2Int downExit = new Vector2Int(LevelGenerator.ROOM_WIDTH / 2, 0);
        Vector2Int leftExit = new Vector2Int(0, LevelGenerator.ROOM_HEIGHT / 2);
        Vector2Int rightExit = new Vector2Int(LevelGenerator.ROOM_WIDTH - 1, LevelGenerator.ROOM_HEIGHT / 2);

        _hasUpExit = IsPointNavigable(indexGrid, upExit);
        _hasDownExit = IsPointNavigable(indexGrid, downExit);
        _hasLeftExit = IsPointNavigable(indexGrid, leftExit);
        _hasRightExit = IsPointNavigable(indexGrid, rightExit);

        _hasUpDownPath = DoesPathExist(indexGrid, upExit, downExit);
        _hasUpLeftPath = DoesPathExist(indexGrid, upExit, leftExit);
        _hasUpRightPath = DoesPathExist(indexGrid, upExit, rightExit);
        _hasDownLeftPath = DoesPathExist(indexGrid, downExit, leftExit);
        _hasDownRightPath = DoesPathExist(indexGrid, downExit, rightExit);
        _hasLeftRightPath = DoesPathExist(indexGrid, leftExit, rightExit);
    }

    public bool MeetsConstrants(ExitConstraint requiredExits)
    {
        ValidateRoom();

        if (requiredExits.upExitRequired && !_hasUpExit)
        {
            return false;
        }
        if (requiredExits.downExitRequired && !_hasDownExit)
        {
            return false;
        }
        if (requiredExits.leftExitRequired && !_hasLeftExit)
        {
            return false;
        }
        if (requiredExits.rightExitRequired && !_hasRightExit)
        {
            return false;
        }
        if (!_hasUpDownPath && requiredExits.upExitRequired && requiredExits.downExitRequired)
        {
            return false;
        }
        if (!_hasUpLeftPath && requiredExits.upExitRequired && requiredExits.leftExitRequired)
        {
            return false;
        }
        if (!_hasUpRightPath && requiredExits.upExitRequired && requiredExits.rightExitRequired)
        {
            return false;
        }
        if (!_hasDownLeftPath && requiredExits.downExitRequired && requiredExits.leftExitRequired)
        {
            return false;
        }
        if (!_hasDownRightPath && requiredExits.downExitRequired && requiredExits.rightExitRequired)
        {
            return false;
        }
        if (!_hasLeftRightPath && requiredExits.leftExitRequired && requiredExits.rightExitRequired)
        {
            return false;
        }
        return true;
    }

    private bool DoesPathExist(int[,] indexGrid, Vector2Int startPoint, Vector2Int endPoint)
    {
        List<Vector2Int> openSet = new List<Vector2Int>();
        List<Vector2Int> closedSet = new List<Vector2Int>();
        if (IsPointNavigable(indexGrid, startPoint))
        {
            openSet.Add(startPoint);
        }
        while (openSet.Count > 0)
        {
            Vector2Int currentPoint = openSet[0];
            openSet.RemoveAt(0);
            if (currentPoint == endPoint)
            {
                return true;
            }
            Vector2Int upNeighbor = new Vector2Int(currentPoint.x, currentPoint.y + 1);
            if (!openSet.Contains(upNeighbor) && !closedSet.Contains(upNeighbor))
            {
                if(IsPointNavigable(indexGrid, upNeighbor))
                {
                    openSet.Add(upNeighbor);
                }
            }
            Vector2Int downNeighbor = new Vector2Int(currentPoint.x, currentPoint.y - 1);
            if (!openSet.Contains(downNeighbor) && !closedSet.Contains(downNeighbor))
            {
                if (IsPointNavigable(indexGrid, downNeighbor))
                {
                    openSet.Add(downNeighbor);
                }
            }
            Vector2Int leftNeighbor = new Vector2Int(currentPoint.x - 1, currentPoint.y);
            if (!openSet.Contains(leftNeighbor) && !closedSet.Contains(leftNeighbor))
            {
                if (IsPointNavigable(indexGrid, leftNeighbor))
                {
                    openSet.Add(leftNeighbor);
                }
            }
            Vector2Int rightNeighbor = new Vector2Int(currentPoint.x + 1, currentPoint.y);
            if (!openSet.Contains(rightNeighbor) && !closedSet.Contains(rightNeighbor))
            {
                if (IsPointNavigable(indexGrid, rightNeighbor))
                {
                    openSet.Add(rightNeighbor);
                }
            }
            closedSet.Add(currentPoint);
        }
        return false;
    }

    private bool IsPointNavigable(int[,] indexGrid, Vector2Int point)
    {
        if (!IsPointInGrid(point))
        {
            return false;
        }
        if(indexGrid[point.x, point.y] == 1)
        {
            return false;
        }
        return true;
    }

    private bool IsPointInGrid(Vector2Int point)
    {
        if (point.x < 0 || point.x > LevelGenerator.ROOM_WIDTH - 1)
        {
            return false;
        }
        if (point.y < 0 || point.y > LevelGenerator.ROOM_HEIGHT - 1)
        {
            return false;
        }
        return true;
    }

    public int[,] loadIndexGrid()
    {
        string initialGridString = designedRoomFile.text;
        string[] rows = initialGridString.Trim().Split('\n');
        int width = rows[0].Trim().Split(',').Length;
        int height = rows.Length;
        if (height != LevelGenerator.ROOM_HEIGHT)
        {
            throw new UnityException(string.Format("Error in room by {0}. Wrong height, Expected: {1}, Got: {2}", roomAuthor, LevelGenerator.ROOM_HEIGHT, height));
        }
        if (width != LevelGenerator.ROOM_WIDTH)
        {
            throw new UnityException(string.Format("Error in room by {0}. Wrong width, Expected: {1}, Got: {2}", roomAuthor, LevelGenerator.ROOM_WIDTH, width));
        }
        int[,] indexGrid = new int[width, height];
        for (int r = 0; r < height; r++)
        {
            string row = rows[height - r - 1];
            string[] cols = row.Trim().Split(',');
            for (int c = 0; c < width; c++)
            {
                indexGrid[c, r] = int.Parse(cols[c]);
            }
        }
        return indexGrid;
    }
}
